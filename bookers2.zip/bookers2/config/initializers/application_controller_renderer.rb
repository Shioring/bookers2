# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '3088e0c28ff776144c5e24c1a12859384ce4b4dcd6062cd9e968af9fc9fbb4c456918d09c42df136fb65bbb13822a93006fc4db7d779a4ad518e6681a9b4b9c7'